import sys

def main():

    param1 = sys.argv[1]
    param2 = sys.argv[2]

    print(f"{param1} {param2}")


if __name__ == "__main__":
    main()